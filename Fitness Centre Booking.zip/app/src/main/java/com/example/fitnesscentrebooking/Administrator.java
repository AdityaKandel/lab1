package com.example.fitnesscentrebooking;

//This is the administrator class


import java.util.ArrayList;

public class Administrator extends User{
    public Administrator(String username, String email, String roleNum, String id, String roleName){
        super(username, email, roleNum, id, roleName);
    }
}
