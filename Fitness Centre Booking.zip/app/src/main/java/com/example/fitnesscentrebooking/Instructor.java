package com.example.fitnesscentrebooking;

import java.util.ArrayList;
import java.util.List;

public class Instructor extends User{

    public Instructor(String username, String email, String roleNum, String id, String roleName){
        super(username, email, roleNum, id, roleName);
    }
    public Instructor(){
    }

}
