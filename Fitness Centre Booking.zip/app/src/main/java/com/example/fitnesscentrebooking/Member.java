package com.example.fitnesscentrebooking;

import java.util.ArrayList;

public class Member extends User{


    public Member(String username, String email, String roleNum, String id, String roleName){
        super(username, email, roleNum, id, roleName);

    }
    public Member(){

    }

}
