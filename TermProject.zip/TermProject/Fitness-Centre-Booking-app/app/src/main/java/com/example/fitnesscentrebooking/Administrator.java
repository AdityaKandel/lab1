package com.example.fitnesscentrebooking;

//This is the administrator class


public class Administrator extends User{
    public Administrator(String username, String email, String role, String id){
        super(username, email, role, id);
    }
}
