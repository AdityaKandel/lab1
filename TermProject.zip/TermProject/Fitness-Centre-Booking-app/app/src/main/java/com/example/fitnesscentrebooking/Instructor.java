package com.example.fitnesscentrebooking;

public class Instructor extends User{


    public Instructor(String username, String email, String role, String id){
        super(username, email, role, id);
    }
}
