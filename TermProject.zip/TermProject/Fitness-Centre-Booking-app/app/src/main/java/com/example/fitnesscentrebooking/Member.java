package com.example.fitnesscentrebooking;

public class Member extends User{


    public Member(String username, String email, String role, String id){
        super(username, email, role, id);

    }

}
